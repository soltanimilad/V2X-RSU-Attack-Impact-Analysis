#include "veins/modules/application/traci/TraCIDemoRSU11p.h"

#include "veins/modules/application/traci/TraCIDemo11pMessage_m.h"
#include "veins/base/utils/FindModule.h"

using namespace veins;

Define_Module(veins::TraCIDemoRSU11p);

void TraCIDemoRSU11p::initialize(int stage)
{
    DemoBaseApplLayer::initialize(stage);

    if (stage == 0) {
        // Read parameters (configure them in NED / omnetpp.ini)
        attackLaneId     = par("attackLaneId").stdstringValue();
        attackStartTime  = par("attackStartTime");
        attackDuration   = par("attackDuration");

        startAttackEvt = new cMessage("startAttack");
        if (attackDuration > 0)
            stopAttackEvt = new cMessage("stopAttack");
        else
            stopAttackEvt = nullptr;

        // Schedule attack (can be at t = 0)
        scheduleAt(simTime() + attackStartTime, startAttackEvt);
    }
    else if (stage == 1) {
        // Only locate the TraCIScenarioManager here.
        // The TraCICommandInterface may still not be ready at this moment.
        manager = FindModule<TraCIScenarioManager*>::findGlobalModule();
        if (!manager) {
            EV_ERROR << "TraCIDemoRSU11p: could not find TraCIScenarioManager module" << endl;
            // Do not throw; we will try again later in startAttack()
        }
    }
}

void TraCIDemoRSU11p::handleSelfMsg(cMessage* msg)
{
    if (msg == startAttackEvt) {
        startAttack();
        return;
    }

    if (msg == stopAttackEvt) {
        stopAttack();
        return;
    }

    // Let the base class handle its own timers (if any)
    DemoBaseApplLayer::handleSelfMsg(msg);
}

void TraCIDemoRSU11p::startAttack()
{
    // If no lane is configured, do nothing
    if (attackLaneId.empty())
        return;

    // Lazy initialization of TraCI interface:
    // try to get it when the attack actually starts, not during init().
    if (!traci) {
        if (!manager)
            manager = FindModule<TraCIScenarioManager*>::findGlobalModule();

        if (!manager) {
            EV_WARN << "TraCIDemoRSU11p: manager not found, retrying attack later" << endl;
            scheduleAt(simTime() + 0.1, startAttackEvt);   // retry after 0.1 s
            return;
        }

        traci = manager->getCommandInterface();
        if (!traci) {
            EV_WARN << "TraCIDemoRSU11p: TraCI not ready yet, retrying attack later" << endl;
            scheduleAt(simTime() + 0.1, startAttackEvt);   // retry after 0.1 s
            return;
        }
    }

    EV_INFO << "RSU launching lane-blocking attack on lane " << attackLaneId
            << " at time " << simTime() << endl;

    // Extract edge ID from lane ID (e.g., "F3F2_0" -> "F3F2")
    std::string edgeId = attackLaneId;
    std::size_t pos = edgeId.find('_');
    if (pos != std::string::npos)
        edgeId = edgeId.substr(0, pos);

    // ====== STEP 1: Block the lane in SUMO (vehicles already on it stay; new ones cannot enter) ======
    auto lane = traci->lane(attackLaneId);

    std::list<std::string> disallowed;
    // Add all vehicle classes used in your SUMO .rou.xml
    disallowed.push_back("passenger");
    disallowed.push_back("truck");
    disallowed.push_back("bus");
    disallowed.push_back("emergency");
    disallowed.push_back("motorcycle");

    lane.setDisallowed(disallowed);
    EV_INFO << "Lane " << attackLaneId << " is now blocked (disallowed)" << endl;

    // ====== STEP 2: Broadcast a fake congestion message for the edge ======
    // Vehicles whose route includes this edge and are NOT yet on it
    // will call changeRoute(edgeId, 9999) in their TraCIDemo11p::onWSM.
    auto* wsm = new TraCIDemo11pMessage();
    populateWSM(wsm);
    wsm->setSenderAddress(myId);
    wsm->setSerial(0);
    wsm->setDemoData(edgeId.c_str());  // edge ID, not lane ID

    sendDown(wsm);
    EV_INFO << "Broadcast congestion message for edge " << edgeId << endl;

    // ====== STEP 3: Optionally schedule end of attack ======
    if (attackDuration > 0 && stopAttackEvt != nullptr)
        scheduleAt(simTime() + attackDuration, stopAttackEvt);
}


void TraCIDemoRSU11p::stopAttack()
{
    if (!traci || attackLaneId.empty())
        return;

    EV_INFO << "RSU ending lane-blocking attack on lane " << attackLaneId
            << " at time " << simTime() << endl;

    // Extract edge ID from lane ID
    std::string edgeId = attackLaneId;
    std::size_t pos = edgeId.find('_');
    if (pos != std::string::npos)
        edgeId = edgeId.substr(0, pos);

    // ====== STEP 1: Remove lane blocking ======
    auto lane = traci->lane(attackLaneId);
    std::list<std::string> none;
    lane.setDisallowed(none);
    EV_INFO << "Lane " << attackLaneId << " is now OPEN again" << endl;

    // ====== STEP 2: Optionally broadcast a "recovery" message ======
    // This tells vehicles that the edge is no longer congested
    // (set travel time back to normal or negative value)
    auto* wsm = new TraCIDemo11pMessage();
    populateWSM(wsm);
    wsm->setSenderAddress(myId);
    wsm->setSerial(0);
    // Use a special marker or negative travel time to indicate "no congestion"
    wsm->setDemoData(edgeId.c_str());

    sendDown(wsm);
    EV_INFO << "Broadcast recovery message for edge " << edgeId << endl;
}

void TraCIDemoRSU11p::onWSA(DemoServiceAdvertisment* wsa)
{
    // Keep the original demo behavior:
    // tune to SCH when RSU receives service 42
    if (wsa->getPsid() == 42) {
        mac->changeServiceChannel(static_cast<Channel>(wsa->getTargetChannel()));
    }
}

void TraCIDemoRSU11p::onWSM(BaseFrame1609_4* frame)
{
    // Keep the original behavior: repeat any congestion message with a small delay
    auto* wsm = check_and_cast<TraCIDemo11pMessage*>(frame);

    // RSU repeats the received traffic update in 2 seconds plus some random delay
    sendDelayedDown(wsm->dup(), 2 + uniform(0.01, 0.2));
}
