#pragma once

#include "veins/modules/application/ieee80211p/DemoBaseApplLayer.h"
#include "veins/modules/mobility/traci/TraCIScenarioManager.h"
#include "veins/modules/mobility/traci/TraCICommandInterface.h"

namespace veins {

/**
 * Hacked RSU application:
 *  - At attackStartTime blocks a given SUMO lane (attackLaneId)
 *  - Broadcasts a fake congestion message so cars reroute away
 *    (using the default TraCIDemo11p::onWSM -> changeRoute()).
 */
class VEINS_API TraCIDemoRSU11p : public DemoBaseApplLayer {
public:
    void initialize(int stage) override;

protected:
    void onWSM(BaseFrame1609_4* wsm) override;
    void onWSA(DemoServiceAdvertisment* wsa) override;
    void handleSelfMsg(cMessage* msg) override;

protected:
    // TraCI access
    TraCIScenarioManager* manager = nullptr;
    TraCICommandInterface* traci = nullptr;

    // Attack configuration (set via NED/omnetpp.ini)
    std::string attackLaneId;       // e.g. "F3F2_0"
    simtime_t attackStartTime = 0;  // when to start blocking (0s = at t=0)
    simtime_t attackDuration = 0;   // 0 => permanent; >0 => restore after this

    // Internal timers
    cMessage* startAttackEvt = nullptr;
    cMessage* stopAttackEvt = nullptr;

    // Internal helpers
    void startAttack();
    void stopAttack();
};

} // namespace veins
